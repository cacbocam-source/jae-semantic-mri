from datetime import datetime, timezone

def get_metric_eligible_records():
    return []

def mark_metrics_failure(doc_id: str, message: str) -> None:
    return None

def mark_metrics_success(doc_id: str) -> None:
    return None

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
