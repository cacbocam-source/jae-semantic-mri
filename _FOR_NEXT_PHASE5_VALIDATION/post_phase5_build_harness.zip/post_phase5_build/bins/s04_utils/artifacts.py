from dataclasses import dataclass
import numpy as np

@dataclass(slots=True)
class MetricsArtifact:
    corpus_name: str
    route_name: str
    epoch_labels: list[str]
    epoch_counts: list[int]
    epoch_centroids: np.ndarray
    semantic_dispersion: np.ndarray
    innovation_velocity: np.ndarray
    source_embedding_files: list[str]
    created_at_utc: str
    metric_version: str
